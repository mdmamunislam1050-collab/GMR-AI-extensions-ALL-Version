/* GMR AI - Version label normalizer (display only, no logic change) */
(function () {
  'use strict';
  var TARGET = '5.21';
  var RE = /([vV])([-.\s]?)5\.\d{1,2}/g;
  var RE2 = /(VERSION[^0-9]{0,6})5\.\d{1,2}/gi;

  function fixText(t) {
    if (!t || t.indexOf('5.') === -1) return t;
    return t.replace(RE, function (m, v, sep) { return v + sep + TARGET; })
            .replace(RE2, function (m, p) { return p + TARGET; });
  }

  function walk(node) {
    if (!node) return;
    if (node.nodeType === 3) {
      var n = fixText(node.nodeValue);
      if (n !== node.nodeValue) node.nodeValue = n;
      return;
    }
    if (node.nodeType !== 1) return;
    if (node.tagName === 'SCRIPT' || node.tagName === 'STYLE') return;
    ['title', 'placeholder', 'alt'].forEach(function (a) {
      if (node.hasAttribute && node.hasAttribute(a)) {
        var v = fixText(node.getAttribute(a));
        if (v !== node.getAttribute(a)) node.setAttribute(a, v);
      }
    });
    for (var c = node.firstChild; c; c = c.nextSibling) walk(c);
  }

  function run() {
    try {
      if (document.title) document.title = fixText(document.title);
      walk(document.body);
    } catch (e) {}
  }

  function start() {
    run();
    try {
      new MutationObserver(function (muts) {
        for (var i = 0; i < muts.length; i++) {
          var m = muts[i];
          if (m.type === 'characterData') walk(m.target);
          for (var j = 0; j < m.addedNodes.length; j++) walk(m.addedNodes[j]);
        }
      }).observe(document.documentElement, {
        childList: true, subtree: true, characterData: true
      });
    } catch (e) {}
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();
