# Recap automation removed

This build removes the active reCAPTCHA auto-open and auto-solve content scripts, their dedicated request rule, and the dedicated host permissions.

The existing extension version remains unchanged. Server/API configuration, all other feature files, visible popup UI, and `content_script/f3_recaptcha_try_skip.js` are retained. The UI controls for reCAPTCHA may remain visible because the popup UI was preserved, but no reCAPTCHA auto-open or auto-solve content script is registered or present in this package.
