@echo off
title GMR AI License Server
echo ===================================================
echo   Starting GMR AI License & Quota Server...
echo ===================================================
cd /d "%~dp0\server"
py app.py
pause
